﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SelfHosting
{
    public class GameController : System.Web.Http.ApiController
    {
        public List<string> GetGameCategories()
        {
            DataTable lcResult = clsDbConnect.GetDataTable("SELECT name FROM category", null);
            List<string> lcNames = new List<string>();
            foreach (DataRow dr in lcResult.Rows)
                lcNames.Add((string)dr[0]);
            return lcNames;
        }

        public List<clsGame> GetCategoryGames(string Catergory)
        {
            Dictionary<string, object> par = new Dictionary<string, object>(1);
            par.Add("Catergory", Catergory);
            DataTable lcResult = clsDbConnect.GetDataTable("SELECT * FROM game WHERE catergory = @Catergory", par);
            List<clsGame> lcGames = new List<clsGame>();
            foreach (DataRow dr in lcResult.Rows)
                lcGames.Add(dataRow2Game(dr));
            return lcGames;

        }

        public List<clsOrder> GetGameOrders()
        {
            DataTable lcResult = clsDbConnect.GetDataTable("SELECT * FROM orders", null);
            List<clsOrder> lcOrders = new List<clsOrder>();
            foreach (DataRow dr in lcResult.Rows)
                lcOrders.Add(dataRow2Order(dr));
            return lcOrders;
        }

        private clsGame dataRow2Game(DataRow prDataRow)
        {
            return new clsGame()
            {
                Id =  Convert.ToInt16(prDataRow["Id"]),
                Name = Convert.ToString(prDataRow["name"]),
                Catergory = Convert.ToString(prDataRow["catergory"]),
                Price  = Convert.ToDecimal(prDataRow["price"]),
                Type = Convert.ToString(prDataRow["type"]),
                Stock = Convert.ToInt16(prDataRow["stock"]),
                Serial = prDataRow["serial"] is DBNull ? (string)null : Convert.ToString(prDataRow["serial"]),
                Weight = prDataRow["weight"] is DBNull ? 0 : Convert.ToInt16(prDataRow["weight"]),
                Download = prDataRow["download"] is DBNull ? (string)null : Convert.ToString(prDataRow["download"]),
                Shipping = prDataRow["shipping"] is DBNull ? 0 : Convert.ToDecimal(prDataRow["shipping"])
            };
        }

        private clsOrder dataRow2Order(DataRow prDataRow)
        {
            return new clsOrder()
            {
                Id = Convert.ToInt16(prDataRow["Id"]),
                Customer_name = Convert.ToString(prDataRow["customer_name"]),
                Date = Convert.ToString(prDataRow["date"]),
                Game_id = Convert.ToInt16(prDataRow["game_id"]),
                Price = Convert.ToDecimal(prDataRow["price"])
            };
        }

        public string DeleteGame(string Id)
        {   // delete
            try
            {
                Dictionary<string, object> par = new Dictionary<string, object>(2);
                par.Add("Id", Id);
                int lcRecCount = clsDbConnect.Execute(
               "DELETE FROM game WHERE Id = @Id", par);
                if (lcRecCount == 1)
                    return "One game deleted";
                else
                    return "Unexpected game delete count: " + lcRecCount;
            }
            catch (Exception ex)
            {
                return ex.GetBaseException().Message;
            }

        }

        public string PutGame(clsGame prGame)
        {   // update
            try
            {
                int lcRecCount = clsDbConnect.Execute(
               "UPDATE game SET stock=@Stock, price=@Price, serial=@Serial, weight=@Weight, download=@Download, shipping=@Shipping WHERE Id = @Id",
               prepareWorkParameters(prGame));
                if (lcRecCount == 1)
                    return "One game updated";
                else
                    return "Unexpected game update count: " + lcRecCount;
            }
            catch (Exception ex)
            {
                return ex.GetBaseException().Message;
            }

        }

        public string PostGame(clsGame prGame)
        {//insert
            try
            {
                int lcRecCount = clsDbConnect.Execute("INSERT INTO game " +
                "(name,catergory,stock,price,type,serial,weight,download,shipping) " +
                "VALUES (@Name,@Catergory,@Stock,@Price,@Type,@Serial,@Weight,@Download,@Shipping)",
                prepareWorkParameters(prGame));
                if (lcRecCount == 1)
                    return "One game inserted";
                else
                    return "Unexpected game insert count: " + lcRecCount;
            }
            catch (Exception ex)
            {
                return ex.GetBaseException().Message;
            }
        }

        public string DeleteOrder(string Id)
        {   // delete
            try
            {
                Dictionary<string, object> par = new Dictionary<string, object>(2);
                par.Add("Id", Id);
                int lcRecCount = clsDbConnect.Execute(
               "DELETE FROM orders WHERE Id = @Id", par);
                if (lcRecCount == 1)
                    return "One Order deleted";
                else
                    return "Unexpected Order delete count: " + lcRecCount;
            }
            catch (Exception ex)
            {
                return ex.GetBaseException().Message;
            }

        }

        private Dictionary<string, object> prepareWorkParameters(clsGame prGame)
        {
            Dictionary<string, object> par = new Dictionary<string, object>(10);
            par.Add("Name", prGame.Name);
            par.Add("Catergory", prGame.Catergory);
            par.Add("Download", prGame.Download);
            par.Add("Price", prGame.Price);
            par.Add("Serial", prGame.Serial);
            par.Add("Shipping", prGame.Shipping);
            par.Add("Stock", prGame.Stock);
            par.Add("Type", prGame.Type);
            par.Add("Weight", prGame.Weight);
            return par;
        }
    }
}
