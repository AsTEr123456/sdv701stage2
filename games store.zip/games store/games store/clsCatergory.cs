﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace games_store
{
    public class clsCatergory
    {
        private string name;
        private string descript;

        public string Name { get => name; set => name = value; }
        public string Descript { get => descript; set => descript = value; }
    }
}
