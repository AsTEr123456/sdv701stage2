﻿// Make by Aster (yuwei zhang) on 22/06/2019
// This class use for store all category data

namespace SelfHosting
{
    public class clsCatergory
    {
        private string name;
        private string descript;

        public string Name { get => name; set => name = value; }
        public string Descript { get => descript; set => descript = value; }
    }
}
